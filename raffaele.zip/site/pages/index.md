---
title: "Index"
permalink: "index.html"
layout: "index.html"
slug: "index"
tags: "pages"
seo:
  title: "Raffaele 🌋 - Product (UX / UI) Designer"
  description: "Raffaele Vitale, UX/UI e Product Designer che allinea strategia, design e sviluppo per avere un impatto positivo su utenti e businesses."
  og_title: "Raffaele 🌋 - Product (UX / UI) Designer"
---


