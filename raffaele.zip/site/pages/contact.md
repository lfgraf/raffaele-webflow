---
title: "Contact"
permalink: "{{ page.fileSlug }}/index.html"
layout: "contact.html"
slug: "contact"
tags: "pages"
seo:
  title: "Raffaele 🌋 - Product (UX / UI) Designer"
  description: "Contatta Raffaele Vitale, UX/UI e Product designer che allinea strategia, design e sviluppo per avere un impatto positivo su utenti e businesses."
  og_title: "Raffaele 🌋 - Product (UX / UI) Designer"
  og_description: "Contatta Raffaele Vitale, UX/UI e Product designer che allinea strategia, design e sviluppo per avere un impatto positivo su utenti e businesses."
  og_type: "website"
  twitter_card: "summary_large_image"
---


