---
_archived: false
_draft: false
gallery-image-1:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60714f73f2177815f9e64246_3.png"
  alt: ""
background-color: "#9ea4b2"
project-title: "Connettere i collezionisti d'arte"
created-on: "2020-10-13T12:16:06.897Z"
gallery-image-2:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60714f7ff15e74eb9254dfb4_6.png"
  alt: ""
gallery-image-3:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60714f6e8de34fa93aa14d25_2.png"
  alt: ""
problem-overview: "Ho gestito la parte di presentazione e decks, la creazione della gestione del brand, la sua comunicazione e la sua interfaccia web da unico Design Manager. "
project-image:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/607a928a3878102361c84d8b_home.png"
  alt: ""
gallery-image-split-left:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60714f77693222e248da2a2c_4.png"
  alt: ""
result-overview: "Oltre ad aver abbattuto costi e tempistiche, il risultato ha avuto un grande impatto sugli stakeholders e sugli utenti attraverso testing interni ed esterni che hanno portato alla ridefinizione di alcune challenges specifiche (flow di aggiunta opere d'arte, e stato delle gallerie)"
name: "Artscapy"
slug: "artscapy"
solution-overview: "In 3 mesi, tramite Notion, processi e pratiche stabilite, ho oggettificato decisioni di design e creato l'esperienza principale (MVP) stabilita per ricevere il primo round di finanziamenti."
new-image:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/607a9266ee46ee550536a28e_Frame%201988.png"
  alt: ""
updated-on: "2021-04-17T07:48:18.599Z"
overview: "Artscapy è uno network in cui gli amanti dell'arte possono riunirsi, esplorare nuove opere, acquistarle e gestire le loro collezioni."
client-overview: "La sfida di Alessandro ed Emilia é stata quella di voler connettere i collezionisti online approfittando della proficua possibilitá di mercato. "
gallery-image-split-right:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60714f7b45729b102021fa71_5.png"
  alt: ""
published-on: "2021-04-17T07:54:34.500Z"
general-content-title: "Lavorare smart, bilanciando qualitá e velocitá "
tags: "projects"
layout: "single-projects.html"
---


