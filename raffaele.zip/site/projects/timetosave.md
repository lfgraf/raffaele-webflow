---
_archived: false
_draft: false
gallery-image-1:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60715185e5f2ceb3b0e3a88e_03.png"
  alt: ""
background-color: "#7a8be0"
project-title: "Un approccio etico al salvare e gestire denaro"
created-on: "2020-10-13T12:11:20.342Z"
gallery-image-2:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/607151918de34f372ea1532f_06.png"
  alt: ""
gallery-image-3:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/607151943b903c086f5f802f_07.png"
  alt: ""
problem-overview: "Lo scopo era quello di garantire un chiaro scope della potenzialitá che TimeToSave doveva raggiungere, allineare investitori e svilupparla attualmente. Di tutte le sfide, l'uso dei colori é stato un compromesso che ho accettato come requirement importante."
project-image:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/6075388c33e5a31afb4df905_time-to-save.png"
  alt: ""
gallery-image-split-left:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60715189181b244095ca7e0f_04.png"
  alt: ""
result-overview: "Passando dalla discovery fino all'implementazione, ho realizzato le interfacce cross platforms reiterando e lavorando con i responsabili, per poi gestire l'hand-off con gli sviluppatori che in questo progetto erano esterni e non hanno collaborato direttamente con me."
name: "Potere nel risparmiare, investire e gestire risorse economiche"
slug: "timetosave"
solution-overview: "Dopo una sessione di brainstorming e una documentazione tra Figma e Notion, ho realizzato l'esperienza mobile con prototipi avanzati per gli sviluppatori in grado di assicurare a TimeToSave un lancio sui mercati di riferimento con una compagnia marketing adeguata"
new-image:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60715181f15e74393054e5bc_02.png"
  alt: ""
updated-on: "2021-04-13T06:22:14.200Z"
overview: "TimeToSave, dall'allineamento delle prioritá al completo risultato"
client-overview: "Il progetto mi é stato commissionato, ed appassionato per il ruolo di ownership che ho avuto "
gallery-image-split-right:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/6071518da3dddf44b3dde6d6_05.png"
  alt: ""
published-on: "2021-04-13T07:16:08.333Z"
tags: "projects"
layout: "single-projects.html"
---


