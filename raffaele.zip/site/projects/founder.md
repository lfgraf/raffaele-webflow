---
_archived: false
_draft: false
gallery-image-1:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/6071584facdb9fcb8bb9849b_03.png"
  alt: ""
background-color: "#9ea4b2"
project-title: "Risultati da Founder, Host e Speaker"
created-on: "2020-10-13T12:12:14.875Z"
gallery-image-2:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/6071585a529e3ccd0c02103d_06.png"
  alt: ""
gallery-image-3:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/6071585d51fa45271e79576f_07.png"
  alt: ""
problem-overview: "Il Problema di Notion é stato creare e mantenere traccia degli utenti, nel momento del loro grande incremento. Per il resto delle attivitá, é stata una scoperta e un qualcosa che mi sentivo valesse la pena di condividere e fare per il bene comune. "
project-image:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60770fd0d28975272ee885e4_Frame%207.png"
  alt: ""
gallery-image-split-left:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60715852672f3c678af25589_04.png"
  alt: ""
result-overview: "Ho creato \"Notion Italia\", raggiunto in 6 mesi piú di 1200 iscritti e aperto uno studio di consulenza esterno collaborando con loro come consulente UX per connettere users e support. design-ERS e Design Informale, i due podcast di cui sono host, hanno raggiunto oltre i 2000 ascolti e 40K views su Youtube."
name: "Notion Ambassador, design-ERS cohost & more"
slug: "founder"
solution-overview: "Attraverso il programma Ambassador da poco stabilito, ho aiutato nella gestione di un database interno di ricerca e analisi di dati utili al supporto e al team di design. "
new-image:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/6071584b8aadc081f278eeae_02.png"
  alt: ""
updated-on: "2021-04-14T16:12:19.100Z"
overview: "Community Founder, Host, Speaker, Writer & more"
client-overview: "Ho trovato affascinante la missione di Notion di dare valore alle persone creando uno spazio dove chiunque puó collegare e connettere le informazioni della propria vita, cosí come con Airbnb e Medium di dare valore alle persone."
gallery-image-split-right:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60715856d6dc710d267452c3_05.png"
  alt: ""
general-overview: "Non avrai mai chiara expertise del settore di riferimento: spendere tempo con i diretti responsabili e capire prima di argomentare decisioni é la chiave per poi esprimere un punto di vista coerente e nel mirino. "
published-on: "2021-04-14T16:12:19.100Z"
general-content-title: "Mai lavorare in silos"
tags: "projects"
layout: "single-projects.html"
---


