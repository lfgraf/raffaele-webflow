---
_archived: false
_draft: false
gallery-image-1:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60716657f21778705ae69699_text.png"
  alt: ""
background-color: "#edf0ff"
project-title: "Contribution + Advocacy + Metrics"
created-on: "2020-10-13T12:07:22.891Z"
gallery-image-2:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/6071680422bccaf083af8b1d_CleanShot%202021-04-10%20at%2010.50.56.png"
  alt: ""
gallery-image-3:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/6071680f72cc4313867fbae9_CleanShot%202021-04-10%20at%2010.55.01.png"
  alt: ""
problem-overview: "Dopo aver partecipato a varie conferenze e cambiato il Language dei miei progetti in un System, volevo fare in modo che il valore di questo \"artefatto\" potesse essere compreso e considerato come una vera e propria anima vivente da mantenere per scalare."
project-image:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60716510f21778337ce69086_DS-guide.png"
  alt: ""
gallery-image-split-left:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/60716667672f3cdad3f277c0_Component.png"
  alt: ""
result-overview: "Su file di accesso riservato, ho offerto workshops, contribuzioni e aiuti nello specifico settore con una tokenizzazione dei componenti agnostici da contesto. Contattami per saperne di piú. "
name: "Design System scalabili"
slug: "design-system"
solution-overview: "Mi sono dedicato alla costruzione di due Design System e di una presentazione che offra consulenza e supporto a designers, sviluppatori, managers e chiunque coinvolto in piccole o medie aziende indicizzando metriche OKRs per utenti, team interno e business in linea con gli obiettivi. "
new-image:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/6071654d462418b07ab8f6c2_ds-2.png"
  alt: ""
updated-on: "2021-04-10T08:56:36.853Z"
overview: "Che problemi risolve un Design System?"
client-overview: "Ho trovato a dir poco affascinante il ruolo nel Design System per gli immensi benefici in lato sviluppo, design e allineamento che puó portare. Attraverso LinkedIn, mi sono connesso con esperti del settore per saperne di piú. "
gallery-image-split-right:
  url: "https://uploads-ssl.webflow.com/60703b59d94a9d52269b0d32/6071666c22bcca6d78af838b_Cerulean.png"
  alt: ""
general-overview: "Il ruolo del Design System Designer va ben oltre la semplice gestione di varianti in Figma e creazione componenti. Ti incuriosisce il discorso? Prenota una sessione con me!"
published-on: "2021-04-13T07:16:08.333Z"
general-content-title: "Non esiste una one-size-fits-all"
tags: "projects"
layout: "single-projects.html"
---


